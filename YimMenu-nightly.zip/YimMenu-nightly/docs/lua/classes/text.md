# Class: text

## Inherit from 1 class: base_text_element

Class representing an imgui text element.

## Functions (1)

### `set_font(font)`

- **Parameters:**
  - `font` (string): The new font name for that imgui text element.

**Example Usage:**
```lua
text:set_font(font)
```


