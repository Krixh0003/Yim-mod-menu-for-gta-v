#include "backend/bool_command.hpp"

namespace big
{
	bool_command g_super_jump("superjump", "SUPER_JUMP", "SUPER_JUMP_DESC", g.self.super_jump);
}