#include "backend/bool_command.hpp"

namespace big
{
	bool_command g_beastjump("beastjump", "BEAST_JUMP", "BEAST_JUMP_DESC",
	    g.self.beast_jump);
}
