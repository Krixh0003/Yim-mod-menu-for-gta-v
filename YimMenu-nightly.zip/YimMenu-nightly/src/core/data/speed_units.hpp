#pragma once
#include "core/enums.hpp"

static const std::string speed_unit_strings[3] = {"km/h", "mi/h", "m/s"};
