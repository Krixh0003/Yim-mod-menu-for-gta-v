#pragma once
#include "fwddec.hpp"

#include <ped/CPedFactory.hpp>