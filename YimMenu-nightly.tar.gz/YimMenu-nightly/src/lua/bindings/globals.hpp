#pragma once

namespace lua::globals
{
	void bind(sol::state& state);
}