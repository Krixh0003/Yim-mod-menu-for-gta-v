#include "sameline.hpp"

namespace lua::gui
{
	void sameline::draw()
	{
		ImGui::SameLine();
	}
}