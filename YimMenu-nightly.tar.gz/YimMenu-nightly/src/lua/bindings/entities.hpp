#pragma once

namespace lua::entities
{
	void bind(sol::state& state);
}