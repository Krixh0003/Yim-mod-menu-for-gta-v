# Class: button

## Inherit from 1 class: base_text_element

Class representing a gui button.
Refer to the tab class documentation for more info (tab:add_button(name, callback))

