# Class: raw_imgui_callback

## Inherit from 1 class: gui_element

Class for representing a raw imgui callback.

