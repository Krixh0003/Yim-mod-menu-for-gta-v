# Class: separator

Class for ImGui::Separator() - separator, generally horizontal. Inside a menu bar or in horizontal layout mode, this becomes a vertical separator.

